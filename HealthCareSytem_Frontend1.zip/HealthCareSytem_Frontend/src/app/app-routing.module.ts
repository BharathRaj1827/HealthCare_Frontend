import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './app-login/app-login.component';
import { RegisterComponent } from './register/register.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { TestComponent } from './test/test.component'
import {CentreComponent} from './centre/centre.component';
import {ViewcentreComponent} from './viewcentre/viewcentre.component';
import {ViewtestComponent} from './viewtest/viewtest.component';
import { ApproveComponent } from './approve/approve.component';
import { ViewappointmentComponent } from './viewappointment/viewappointment.component';
import {DisplayappointmentComponent} from './displayappointment/displayappointment.component';

const routes: Routes = [
  {path:'loguser',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'home',component: HomeComponent},
  {path:'userLogin',component: UserComponent},
  {path:'adminLogin',component: AdminComponent},
  {path:'addcentre',component: CentreComponent},
  {path:'addtest',component: TestComponent},
  {path:'viewcentre',component: ViewcentreComponent},
  {path:'viewtest',component: ViewtestComponent},
  {path:'approve',component: ApproveComponent},
  {path:'viewappt',component: ViewappointmentComponent},
  {path:'addappt',component:DisplayappointmentComponent},
  {path:'getappt',component:ViewappointmentComponent}

   ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
