import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
 import { MyserviceService, Test } from '../myservice.service';

@Component({
  selector: 'app-viewtest',
  templateUrl: './viewtest.component.html',
  styleUrls: ['./viewtest.component.css']
})
export class ViewtestComponent implements OnInit {
message: string;
test: Test[];

  constructor(private myservice: MyserviceService,private router: Router) { } 
  ngOnInit(): void {
    this.myservice.getTests().subscribe(
      response => this.handleSuccessfulResponse(response),
    ); 
  }
  handleSuccessfulResponse(response) {
    this.test = response;
  }
  update1(updatetest: Test) {
    this.myservice.update1(updatetest);
    this.router.navigate(['/updatetests']); //updating the test
  }
  delete1(deletetest: Test): any {
    this.myservice.delete1(deletetest.testid).subscribe(data => {
      this.message = data
    });
    this.router.navigate(['/admin']);
  }
}
