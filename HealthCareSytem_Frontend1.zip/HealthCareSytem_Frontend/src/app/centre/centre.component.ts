import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Centre } from '../myservice.service';

@Component({
  selector: 'app-centre',
  templateUrl: './centre.component.html',
  styleUrls: ['./centre.component.css']
})
export class CentreComponent implements OnInit{

  message: string;

  constructor(private myservice: MyserviceService,private router: Router) {
    
  }

  ngOnInit(): void {
  }
  OnSubmit(addcentre:Centre):any{
    console.log(addcentre);
     this.myservice.Centre(addcentre).subscribe(data => {
      this.message=data});
}
}