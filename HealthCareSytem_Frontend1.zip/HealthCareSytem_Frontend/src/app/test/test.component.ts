import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Test } from '../myservice.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
message: string;

  constructor(private myservice: MyserviceService,private router: Router) { }

  ngOnInit(): void {
  }
     OnSubmit(addtest:Test):any{
      console.log(addtest);
       this.myservice.Test(addtest).subscribe(data => {
        this.message=data});
      } 
  
}
