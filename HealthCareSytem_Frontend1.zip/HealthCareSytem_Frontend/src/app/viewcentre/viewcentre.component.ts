import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Centre } from '../myservice.service'; 


@Component({
  selector: 'app-viewcentre',
  templateUrl: './viewcentre.component.html',
  styleUrls: ['./viewcentre.component.css']
})
export class ViewcentreComponent implements OnInit {
message: string;
centre: Centre[];

constructor(private myservice: MyserviceService,private router: Router) { } 

  ngOnInit(): void {
    this.myservice.getCentre().subscribe(
      response => this.handleSuccessfulResponse(response),
    ); 
  }
  handleSuccessfulResponse(response) {
    this.centre = response;
  }
  update(updatecentre: Centre) {
    this.myservice.update(updatecentre);
    this.router.navigate(['/updatecen']); //updating the centre
  }
  delete(deletecentre: Centre): any {
    this.myservice.delete(deletecentre.centreid).subscribe(data => {
      this.message = data
    });
    this.router.navigate(['/admin']);
  } 
}
