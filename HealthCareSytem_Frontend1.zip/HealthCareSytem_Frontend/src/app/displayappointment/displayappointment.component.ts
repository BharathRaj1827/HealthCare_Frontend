import { Component, OnInit } from '@angular/core';
import { MyserviceService, Centre, Test, Appointment } from '../myservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-displayappointment',
  templateUrl: './displayappointment.component.html',
  styleUrls: ['./displayappointment.component.css']
})
export class DisplayappointmentComponent implements OnInit {
  selectedTest: Test;
  test_details: any
  checkTests: boolean = false
  centre: Centre
  tests: Test
  selectedCentreid: string;
  selectedDate: string
  dateCheck: boolean = false;
  usersidCheck: boolean = false;
  appointment: string;
  confirmation: boolean;

  user: Centre = new Centre("", "", "","",[]);
  tester: Test = new Test("", "","");

  app: Appointment = new Appointment(false, "", "", "","");

  constructor(private myservice: MyserviceService, private router: Router) { }

  ngOnInit(): void {
    this.getAllCenters();
  }

  onSelect(user: Centre) {
    this.selectedCentreid = user.centreid;
    this.myservice.displayTests(this.selectedCentreid).subscribe(
      response => this.handleSuccessfulResponseTest(response),
    );
    this.app.centrenumber = user.centrename;
  }

  handleSuccessfulResponseTest(response) {
    this.tests = response;
  }

  onTest(tester) {
    this.dateCheck = true;
    this.app.testnames = tester.testname;
  }

  onDate() {
    if (this.app.datetime == "") {
      window.alert("Please select a valid date and time");

    } else {
      this.usersidCheck = true;
      this.app.appointmentstatus = false;
    }
  }

  onConfirm() {

    if (this.app.usersid == "") {
      window.alert("Please enter a valid userId");

    } else {
      this.myservice.makeAppointment(this.app)
      .subscribe(data => {
        if(data){
          this.dateCheck=false;
          this.usersidCheck=false;
          this.confirmation=true;
       alert("Appointment added successfully! Please check View Appointments");
        }else{
          alert("user ID already exists!! This user already made an appointment");
        }
      });
    }
  }

  getAllCenters() {
    //getting data of all Centers

    this.myservice.displayCenters().subscribe(
      response => this.handleSuccessfulResponseCenter(response),
    );
  }
  handleSuccessfulResponseCenter(response) {
    this.centre = response;
  }


}
  
  
