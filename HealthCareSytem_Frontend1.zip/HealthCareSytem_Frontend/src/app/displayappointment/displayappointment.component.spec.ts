import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayappointmentComponent } from './displayappointment.component';

describe('DisplayappointmentComponent', () => {
  let component: DisplayappointmentComponent;
  let fixture: ComponentFixture<DisplayappointmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayappointmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayappointmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
