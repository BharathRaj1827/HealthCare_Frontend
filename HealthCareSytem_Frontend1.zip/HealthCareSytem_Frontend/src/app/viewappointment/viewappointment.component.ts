import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Appointment, MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-viewappointment',
  templateUrl: './viewappointment.component.html',
  styleUrls: ['./viewappointment.component.css']
})
export class ViewappointmentComponent implements OnInit {
  message:string;
  appointment:Appointment;


  usersid:number;
  search:boolean=false;
  search1:boolean=false;
  private router: Router
  constructor(private myservice: MyserviceService, router: Router) { 
    this.router=router;
  }
  ngOnInit(): any {
  }
  getappt(){
    this.myservice.getAppointment(this.usersid).subscribe((data)=>this.appointment=data);
    if(this.appointment == null){
      this.search1 = true;
      this.search = false;
    }
    else{
      this.search1 = false;
      this.search= true;
    }
  }


  
          //constructor(private myservice: MyserviceService,private router: Router) { } 

          // ngOnInit(): void {
          //   this.myservice.getAppointment(4).subscribe(
          //     response => this.handleSuccessfulResponse(response),
          //   ); 
          // }
          // handleSuccessfulResponse(response) {
          //   this.appointment = response;
          // }
  
}
