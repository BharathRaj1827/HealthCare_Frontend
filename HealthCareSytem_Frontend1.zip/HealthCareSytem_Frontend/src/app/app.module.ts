
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './app-login/app-login.component';
import { RegisterComponent } from './register/register.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { HomeComponent } from './home/home.component';
import { CentreComponent } from './centre/centre.component';
import { TestComponent } from './test/test.component';
import { ViewcentreComponent } from './viewcentre/viewcentre.component';
import { ViewtestComponent } from './viewtest/viewtest.component';
import { ApproveComponent } from './approve/approve.component';
import { ViewappointmentComponent } from './viewappointment/viewappointment.component';
import {DisplayappointmentComponent} from './displayappointment/displayappointment.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    UserComponent,
    AdminComponent,
    AboutusComponent,
    HomeComponent,
    CentreComponent,
    TestComponent,
    ViewcentreComponent,
    ViewtestComponent,
    ApproveComponent,
    ViewappointmentComponent,
    DisplayappointmentComponent,
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,FormsModule
  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
