import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root' 
})
export class MyserviceService {
  
  updateuser: Users;
  updatecentre: Centre;
  updatetest: Test;
  updateapp: Appointment;
  constructor(private httpService: HttpClient) { }

  public loginAdmin(aname:string, apwd:string){
    return this.httpService.get("http://localhost:8758/admin/valid/"+aname+"/"+apwd,{responseType:'json'});
  }

  public loginUser(uname:string, pwd:string){
    return this.httpService.get("http://localhost:8764/user/valid/"+uname+"/"+pwd,{responseType:'json'});
  }
  
  public login(loginUser: Users) {
    console.log("ins service loginUser");
    console.log(loginUser);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:8586/login/user", loginUser,  { headers, responseType: 'text'});
  }


  public getAppointment(usersid:number) {
    console.log("ins service get appointment");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Appointment>("http://localhost:8764/user/getAppointment/"+usersid);
  }


  public getAllAppointment() {
    console.log("ins service get appointment");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Appointment>("http://localhost:8758/admin/getAllAppointments");
  }

public displayAppointments(){
  return this.httpService.get<Appointment>("http://localhost:8758/admin/getAllAppointments");
}

public approveAppointment(app){
  return this.httpService.put<any>("http://localhost:8758/admin/approveAppointment",app,{responseType:'json'});

}


  public getCentre() {
    console.log("ins service get centres");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Centre>("http://localhost:8758/admin/getAllCenters");
  }

  public getCentres() {
    console.log("ins service get centres");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Centre>("http://localhost:8764/user/getAllCenters");
  }


  public getTests() {
    console.log("ins service get tests");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Test>("http://localhost:8758/admin/getAllTests");
  }

  public getTestsl(selectedCentreid:string) {
    console.log("ins service get tests");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Test>("http://localhost:8764/user/getAllTests/"+selectedCentreid,{responseType:'json'});
  }
  public displayTests(selectedCenterId){
    return this.httpService.get<Test>("http://localhost:8764/user/getAllTests/"+selectedCenterId,{responseType:'json'});
  }
  public makeAppointment(app){
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:8764/user/makeAppointment",app,{headers,responseType:'text'});

  }

  public displayCenters(){
    return this.httpService.get<Centre>("http://localhost:8764/user/getAllCenters");
  }


  public register(registerUser: Users) {
    console.log("ins service loginUser");
    console.log(registerUser);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:8764/user/addUser", registerUser,  { headers, responseType: 'text'});
  }
  public Centre(addcentre: Centre) {
    console.log("ins service add");
    console.log(addcentre);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:8758/admin/addCenter", addcentre,  { headers, responseType: 'text'});
  }
  public Test(addtest: Test) {
    console.log("ins service add");
    console.log(addtest);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:8758/admin/addTest", addtest,  { headers, responseType: 'text'});
 }
 public Users(addappt: Users) {
  console.log("ins service add");
  console.log(addappt);
  const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
  return this.httpService.post("http://localhost:8764/user/makeAppointment", addappt,  { headers, responseType: 'text'});
}
public update(updatecentre: Centre) {
  this.updatecentre = updatecentre;
}
public updateMethod() {
  return this.updatecentre;
}
public onUpdate(updatecen: Centre) {
  console.log("ins service update");
  const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
  return this.httpService.put("http://localhost:8586/centre/UpdateCentre", updatecen,  { headers, responseType: 'text'});
}
delete(centreid: string) {
  console.log("ins service delete");
  const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
  return this.httpService.delete("http://localhost:8758/admin/removeCenter/" + centreid,  { headers, responseType: 'text'});
}
public update1(updatetest: Test) {
  this.updatetest = updatetest;
}
public updateMethod1() {
  return this.updatetest;
}

public onUpdatetest(updatetests: Test) {
  console.log("ins service update");
  const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
  return this.httpService.put("http://localhost:8386/test/UpdateTest", updatetests,  { headers, responseType: 'text'});
}

public onUpdateapp1(updateapp: Appointment) {
  this.updateapp = updateapp;
}
public updateMethod2() {
  return this.updateapp;
}

public onUpdateapp(updateapp:Appointment) {
  console.log("ins service update");
  const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
  return this.httpService.put("http://localhost:8758/admin/approveAppointment", updateapp,  { headers, responseType: 'text'});
}


delete1(testid: string) {
  console.log("ins service delete");
  const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
  return this.httpService.delete("http://localhost:8758/admin/removeTest/" + testid,  { headers, responseType: 'text'});
}
}
export class Users { 
  constructor(
    public userid: string,
    public password: string,
    public phonenumber: number,
    public name: string,
    public age: number,
    public gender: string,
    public email: string )
    {}
}
export class Centre {
   constructor(
    public centreid: string,
    public centrename: string,
    public centrePhno: string,
    public centreAdd: string,
    public listOfTests : any)
    {}
}

export class Admins {
  Adminid: number;
  Adminname: string;
  Adminpassword: string;
}

export class Test {
  constructor(
    public testid: string,
    public testname: string,
    public centrenum: string)
  {}
}

export class Appointment{
  //approved: boolean;
  constructor( 
    //public appointmentid:number,
    public appointmentstatus:boolean,
    public datetime:string,
    public centrenumber:any,
    public testnames:any,
    public usersid:string){}
}