import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Users } from '../myservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './app-login.component.html',
  styleUrls: ['./app-login.component.css']
})
export class LoginComponent implements OnInit {

  message: string;

 adminname:string;
 adminpassword:string;
 name:string;
 password:string;
 a:any;
 us:any;
 checkAuthentication0:boolean = true;
 checkAuthentication1:boolean = false;
 checkAuthentication2:boolean = false;


  constructor(private myservice: MyserviceService,private router: Router) { }

  ngOnInit(): void {}
/*
  OnSubmit (loginUser:Users):any{
    console.log(loginUser.userid);
    console.log(loginUser.password);
    this.myservice.login(loginUser).subscribe(data => {
      this.message=data});
      
      if(loginUser.userid == 'User'){
        this.router.navigateByUrl('/userLogin');
      }else if(loginUser.userid=='Admin'){
        this.router.navigateByUrl('/adminLogin');
      }
    };     
  */
 
 uLogin(){
  this.myservice.loginUser(this.name, this.password).subscribe((data)=>this.us=data);
  if(this.us!= null){
    this.checkAuthentication1 = true;
    this.checkAuthentication2 = false;
    this.checkAuthentication0 = false;
    this.router.navigate(['/userLogin']);
  }
  else{
    this.checkAuthentication2 = true;
    this.checkAuthentication1 = false;
  }
}



  aLogin(){
    this.myservice.loginAdmin(this.adminname, this.adminpassword).subscribe((data)=>this.a=data);
    if(this.a != null){
      this.checkAuthentication1 = true;
      this.checkAuthentication2 = false;
      this.checkAuthentication0 = false;
      this.router.navigate(['/adminLogin']);
    }
    else{
      this.checkAuthentication2 = true;
      this.checkAuthentication1 = false;
    }
  }
}
