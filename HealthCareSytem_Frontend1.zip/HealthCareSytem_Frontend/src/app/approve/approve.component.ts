import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Centre, Test, Appointment } from '../myservice.service';

@Component({
  selector: 'app-approve',
  templateUrl: './approve.component.html',
  styleUrls: ['./approve.component.css']
})
export class ApproveComponent implements OnInit {

  app:Appointment;
  test:Test;
  center:Centre;
  status:string;
  appointment:string;

  constructor(private myservice:MyserviceService,private router: Router) { }

  ngOnInit(): void {
    this.getAllAppointments();
  }
  getAllAppointments() {
    //getting data of all appointments

    console.log(this.app)
    this.myservice.displayAppointments().subscribe(
     response =>this.handleSuccessfulResponseCenter(response),
    );
  }
  handleSuccessfulResponseCenter(response)
  {
     this.app=response;
  }


  onClick(app){
    console.log(app);
    app.appointmentstatus=true;
    console.log(app);
    this.myservice.approveAppointment(app).subscribe((data) =>this.appointment = data);

  }

statusCheck(){
  if (this.app.appointmentstatus=false){
    status="awaiting confirmation"
}else {
status="Your Appointment is scheduled!"
}
}

}







