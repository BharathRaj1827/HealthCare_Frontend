import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Centre, Test, MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  message: string;
  centre: Centre[];
  test:Test[];
  showtests: boolean = true;



constructor(private myservice: MyserviceService,private router: Router) { } 

  ngOnInit(): void {}


  addappt(){
    this.router.navigateByUrl('/addappt');
  }
  viewappt(){
    this.router.navigateByUrl('/viewappt');
  }
  logout(){
    this.router.navigateByUrl('/home');
  }
}