import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { MyserviceService, Users } from '../myservice.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 message: string;
  
 constructor(private myservice: MyserviceService,private router: Router) { }

  ngOnInit(): void {
  }

   OnSubmit (registerUser:Users):any{
    console.log(registerUser);
    this.myservice.register(registerUser).subscribe(data => {
    this.message=data});
  } 

}
